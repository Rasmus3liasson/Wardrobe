package com.example.roundUp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RoundUpApplication {

	public static void main(String[] args) {
		SpringApplication.run(RoundUpApplication.class, args);
	}

}
