package com.example.roundUp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RoundUpApplicationTests {

	@Test
	void contextLoads() {
	}

}
